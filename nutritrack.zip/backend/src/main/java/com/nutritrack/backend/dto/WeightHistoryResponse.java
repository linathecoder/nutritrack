package com.nutritrack.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;

@Getter
@AllArgsConstructor
public class WeightHistoryResponse {
    /** Null until the user sets a target weight. */
    private Double targetWeightKg;
    /** Oldest first. Only days with a weigh-in appear. */
    private List<WeightResponse> entries;
}
