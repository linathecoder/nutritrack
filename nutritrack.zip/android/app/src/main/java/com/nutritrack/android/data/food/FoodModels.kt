package com.nutritrack.android.data.food

/**
 * Models of assets/ingredients_full.json (loaded with Gson).
 * Every property has a default so Gson can use the generated no-arg constructor and tolerate missing fields.
 */
data class Per100g(
    val kcal: Double = 0.0,
    val protein: Double = 0.0,
    val carbs: Double = 0.0,
    val fat: Double = 0.0,
    val fiber: Double = 0.0,
    val sugar: Double = 0.0,
    val satFat: Double = 0.0,
    val sodiumMg: Double = 0.0
)

/** A household measure: [grams] is the weight of ONE [label] (e.g. "cup, chopped" = 170 g). */
data class Portion(
    val label: String = "",
    val grams: Double = 0.0
)

data class FoodItem(
    val id: String = "",
    val name: String = "",
    val nameFr: String? = null,
    val category: String = "",
    val icon: String = "",
    val per100g: Per100g = Per100g(),
    val portions: List<Portion> = emptyList(),
    /** True for the hand-curated everyday ingredients (shown first, they have a French name). */
    val popular: Boolean = false,
    /** [NutrientKey]s this food does not list (scanned products with gaps). Their 0 values mean "unknown". */
    val missing: Set<String> = emptySet()
)

data class FoodCategory(
    val id: String = "",
    val name: String = "",
    val nameFr: String? = null,
    val tint: String = "#F0F7F3"
)

data class FoodDataset(
    val version: Int = 0,
    val categories: List<FoodCategory> = emptyList(),
    val ingredients: List<FoodItem> = emptyList()
)

/**
 * USDA names are long ("Chicken, broilers or fryers, breast, meat only, raw"). For sentences we keep the first
 * three parts and the preparation state (raw / cooked / dry) at the end.
 */
fun FoodItem.shortName(): String {
    val parts = name.split(", ")
    if (parts.size <= 3) return name
    val head = parts.take(3).joinToString(", ")
    val tail = parts.last()
    val keepTail = listOf("raw", "cooked", "dry", "boiled", "roasted", "grilled").any { tail.startsWith(it, ignoreCase = true) }
    return if (keepTail) "$head, $tail" else head
}
