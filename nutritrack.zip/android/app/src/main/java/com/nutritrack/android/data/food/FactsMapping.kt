package com.nutritrack.android.data.food

import com.nutritrack.android.data.openfoodfacts.NutrientValues

/**
 * Open Food Facts values -> [Facts]. Anything the product does not list stays null (unknown, not zero).
 * Calories are rebuilt from the macros (4/4/9 kcal per g) only when all three macros are listed.
 */
fun NutrientValues.toFacts(): Facts {
    val kcalValue = kcal ?: if (proteinG != null && carbsG != null && fatG != null) {
        proteinG * 4 + carbsG * 4 + fatG * 9
    } else null
    return Facts(
        kcal = kcalValue,
        protein = proteinG,
        carbs = carbsG,
        fat = fatG,
        fiber = fiberG,
        sugar = sugarsG,
        satFat = saturatedFatG,
        sodiumMg = sodiumMg
    )
}
