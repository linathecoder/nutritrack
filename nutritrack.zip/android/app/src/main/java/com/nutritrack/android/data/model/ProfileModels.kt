package com.nutritrack.android.data.model

data class ProfileCalculationRequest(
    val name: String? = null,
    val sex: String,
    val weightKg: Double,
    val heightCm: Double,
    val age: Int,
    val activityLevel: String,
    val workoutFrequency: String,
    val goal: String,
    /** Optional; when null the server keeps the current target weight. */
    val targetWeightKg: Double? = null
)

data class ProfileCalculationResponse(
    val userId: String?,
    val profileId: String?,
    val macroTargetId: String?,
    val name: String?,
    val sex: String?,
    val weightKg: Double?,
    val heightCm: Double?,
    val age: Int?,
    val activityLevel: String?,
    val workoutFrequency: String?,
    val goal: String?,
    val bmr: Double?,
    val tdee: Double?,
    val calories: Int?,
    val proteinG: Double?,
    val carbsG: Double?,
    val fatG: Double?,
    val targetWeightKg: Double? = null
)

/** Body of POST api/weight. [date] (yyyy-MM-dd) defaults to today on the server. */
data class WeightRequest(
    val weightKg: Double,
    val date: String? = null
)

data class WeightEntryDto(
    val date: String,
    val weightKg: Double
)

/** Weigh-ins (oldest first, only days that have one) and the target weight, if set. */
data class WeightHistoryResponse(
    val targetWeightKg: Double? = null,
    val entries: List<WeightEntryDto> = emptyList()
)
